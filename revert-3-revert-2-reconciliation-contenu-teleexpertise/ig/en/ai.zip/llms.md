# ans.fhir.fr.teleexpertise-confluence#0.1.0: Confluences Téléexpertise(en)

## Pages

* [Accueil](index.md)
* [Autres Ressources](autres_ressources.md)
* [Contexte administratif de la demande](specification_requerant.md)
* [Historique des versions](change-log.md)
* [Flux des statuts](specification_statuts.md)
* [Flux de la demande](specification_enrichi.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](annexe-downloads.md)
* [Informations sur la traduction](translationinfo.md)
* [Sécurité](annexe-securite.md)

## Resources

### CodeSystems

* [ActiveStatusCS](CodeSystem-active-status-cs.md)

### ValueSets

* [NameUse Usual Or Official](ValueSet-NameUseUsualOrOfficial.md)
* [ActiveStatus](ValueSet-activestatus.md)

### Resource Profiles

* [CFL HealthcareService Profile](StructureDefinition-CFL-HealthcareService-profile.md)
* [CFL Organization Profile](StructureDefinition-cfl-Organization.md)
* [CFL ServiceRequest Enrichi Profile](StructureDefinition-cfl-ServiceRequest-enrichi.md)
* [CFL ServiceRequest Requerant Profile](StructureDefinition-cfl-ServiceRequest-requerant.md)
* [CFL Patient Profile](StructureDefinition-cfl-patient.md)
* [CFL Practitioner Profile](StructureDefinition-cfl-practitioner.md)
* [CFL PractitionerRole Profile](StructureDefinition-cfl-practitionerrole.md)
* [Cfl Transaction Response](StructureDefinition-cfl-transaction-response-bundle.md)

### Extensions

* [Patient Consent](StructureDefinition-patient-consent.md)
* [Patient Multiple Birth](StructureDefinition-patient-multiple-birth.md)
* [Redirect Url](StructureDefinition-redirect-url.md)
* [Split Active Status](StructureDefinition-split-active-status.md)
* [Url Ltle](StructureDefinition-url-ltle.md)

### ImplementationGuides

* [Confluences Téléexpertise](ImplementationGuide-ans.fhir.fr.teleexpertise-confluence.md)
